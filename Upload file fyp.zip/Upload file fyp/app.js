const express = require('express');
const app = express();
const path = require('path');
const moment = require('moment');
const multer = require('multer');
const dateFormat = require('dateformat');
//var JSAlert = require("js-alert");

//const popups = require('popups');

var NodeGeocoder = require('node-geocoder');
const dbConnection = require('./DbConnection/dbconnection');
let loginUserID;
let loginUserName;
let loginUserImage;
let SelectTailorID;
let SelectTailorName;
let alertdialoginformsubmission = false;
let nowTime = Date.now();
let loginUserType;
//
// let nowTimer=dateFormat(nowTime, "dddd, mmmm dS, yyyy, h:MM:ss TT");
let nowTimer = dateFormat(nowTime);
// let nowTimer1=dateFormat(nowTime);

//
// console.log('ddddddddddddddddddddddddddddddddd  '+nowTimer1);
// console.log('cccccccccccccccccccccccccccccccccccccccccccccccccccc  '+nowTimer);

//let nowTimer=Date.now();

//const mysql = require('mysql');
const bodyParser = require('body-parser');
//let MySQLEvents = require('mysql-events');
//const validator = require('express-validator');

app.use(express.static(__dirname + '/public')); // Public folder is use to style the website..
app.use(bodyParser.urlencoded({ extended: true }));
app.set('views', path.join(__dirname, 'views/pages'));
app.set('view engine', 'ejs');
//var absolutePath = path.resolve(__dirname+'/views/pages');
//const {check,validationResult} = require('express-validator/check');
//const {matchedData ,sanitize} = require('express-validator/filter');

var appc = require('http').Server(app),
  io = require('socket.io').listen(appc),
  fs = require('fs'),
  mysql = require('mysql'),
  connectionsArray = [],

  connection = mysql.createConnection({
    connectionLimit: '10',
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'fyp',
    port: 3306
  }),

  POLLING_INTERVAL = 3000,
  pollingTimer;

// var connections = require('express-myconnection'),
//   mysqli = require('mysql');



// app.use(

//   connections(mysqli, {
//     host: 'localhost',
//     user: 'root',
//     password: '',
//     database: 'fyp',
//     debug: false //set true if you wanna see debug logger
//   }, 'request')

// );

// If there is an error connecting to the database
connection.connect(function (err) {
  // connected! (unless `err` is set)
  if (err) {
    console.log(err);
  }
});

// creating the server ( localhost:8000 )
appc.listen(8000, () => {
  console.log('Listining at port 8000');
});


/*
 *
 * HERE IT IS THE COOL PART
 * This function loops on itself since there are sockets connected to the page
 * sending the result of the database query after a constant interval
 */


// var now = moment();
var pollingLoop = function () {

  // Doing the database query
  //SELECT * FROM `notification`   ORDER BY orderidfk DESC
  var query = connection.query('SELECT * FROM notification where reciverid=' + loginUserID + " ORDER BY notificationid DESC");
  // console.log(moment().startOf('day').fromNow());

  //  console.log(moment(nowTimer).toNow(true) +"Ago") // "a day ago"


  users = []; // this array will contain the result of our db query

  // setting the query listeners
  query
    .on('error', function (err) {
      // Handle error, and 'end' event will be emitted after this as well
      //  console.log(err);
      updateSockets(err);
    })
    .on('result', function (user) {

      // it fills our array looping on each user row inside the db
      users.push(user);
    })
    .on('end', function () {
      // loop on itself only if there are sockets still connected
      if (connectionsArray.length) {

        pollingTimer = setTimeout(pollingLoop, POLLING_INTERVAL);

        updateSockets({
          users: users,
          "moment": moment
        });
      } else {

        //       console.log('The server timer was stopped because there are no more socket connections on the appc')

      }
    });
};


// creating a new websocket to keep the content updated without any AJAX request
io.sockets.on('connection', function (socket) {

  //console.log('Number of connections:' + connectionsArray.length);
  // starting the loop only if at least there is one user connected
  if (!connectionsArray.length) {
    pollingLoop();
  }

  socket.on('disconnect', function () {
    var socketIndex = connectionsArray.indexOf(socket);
    //  console.log('socketID = %s got disconnected', socketIndex);
    if (~socketIndex) {
      connectionsArray.splice(socketIndex, 1);
    }
  });

  console.log('A new socket is connected!');
  connectionsArray.push(socket);

});


var updateSockets = function (data) {
  // adding the time of the last update

  data.time = new Date();
  // console.log('Pushing new data to the clients connected ( connections amount = %s ) - %s',
  //connectionsArray.length , data.time);

  // sending new data to all the sockets connected
  connectionsArray.forEach(function (tmpSocket) {
    tmpSocket.volatile.emit('notification', data);
  });
};

//console.log('Please use your browser to navigate to http://localhost:8000');


app.get('/login/index', (req, res) => {

  fs.readFile(res.render('index.ejs'), function (err, data) {
    if (err) {
      console.log(err);
      res.writeHead(500);
      return res.end('Error loading check.html');
    }
    res.writeHead(200);

    res.end(data);
  });
})


app.get('/pakphenawa', (req, res) => {

  res.render('pakphenawa.ejs')
})


app.post('/pakphenawa', (req, res) => {

  res.render('pakphenawa.ejs')
})


app.post('/signup', (req, res) => {

  res.render('signUp.ejs')
})

app.get('/signup', (req, res) => {

  res.render('signUp.ejs')
})

app.post('/signIn', (req, res) => {
  //console.log(dateFormat(1575024968812, "dddd, mmmm dS, yyyy, h:MM:ss TT"));
  res.render('login.ejs');
})


app.post('/Tailor', (req, res) => {
  //console.log(dateFormat(1575024968812, "dddd, mmmm dS, yyyy, h:MM:ss TT"));
  res.redirect('http://localhost:3000/signIn');


})

let loginUserPassword;
app.post('/index', (req, res) => {

  connection.query('SELECT * FROM login WHERE name = ? AND password = ?', [req.body.Username, req.body.Password], (error, res2, field) => {

    console.log(res2[0].type);
    loginUserType=res2[0].type;
    loginUserPassword = req.body.Password;
    loginUserID = res2[0].id;
    loginUserName = res2[0].name;
    loginUserImage = res2[0].imageaddress;

    var totalOrdersend = 0;
    var waitingforacceptsend = 0;
    var penddingordersend = 0;
    var totalTailorattach = 0;

    if (res2[0].type==="u") {
       connection.query("SELECT * FROM `order`  where userid=" + loginUserID, (error, res3, field) => {

      for (var i = 0; i < res3.length; i++) {

        if (res3[i].orderStatus === "wfa") {
          waitingforacceptsend++;
        }
        //pendding
        if (res3[i].orderStatus === "pendding") {
          penddingordersend++;
        }

        totalOrdersend++;
      }


      connection.query("SELECT * FROM `history`  where userid=" + loginUserID, (error, res4, field) => {

        totalTailorattach = res4.length;

        //    res.redirect('http://localhost:3000/login');
        // console.log('Total order send '+totalOrdersend);
        //  console.log('waiting order send '+waitingforacceptsend);
        //  console.log('pennding order send '+penddingordersend);
        //   console.log('Tailor order send '+totalTailorattach);

        if (res2.length > 0) {

          //  if(res2[0].type=="u"){

          //console.log('wellcome to users ');

          res.render('index', {
            "Username": res2[0].name,
            "type": res2[0].type,
            "imageaddress": res2[0].imageaddress,
            "totalOrdersend": totalOrdersend,
            "waitingforacceptsend": waitingforacceptsend,
            "penddingordersend": penddingordersend,
            "totalTailorattach": totalTailorattach


          });
        }
      })
    })
    }



    if (res2[0].type==="t") {
      
   console.log(res2[0].type);
    loginUserID = res2[0].id;
    loginUserName = res2[0].name;
    loginUserpass = res2[0].password;
    loginUserImage = res2[0].imageaddress;
    let totalOrdersend = 0;
    let penddingordersend = 0;
    let totalTailorattach = 0;


    connection.query("SELECT * FROM `order`  where tailorid=" + loginUserID, (error, res3, field) => {

      for (var i = 0; i < res3.length; i++) {


        //pendding
        if (res3[i].orderStatus === "confirm") {
          penddingordersend++;
        }

        totalOrdersend++;
      }


      connection.query("SELECT * FROM `history`  where tailorid=" + loginUserID, (error, res4, field) => {

        totalTailorattach = res4.length;

        //    res.redirect('http://localhost:3000/login');

        connection.query("SELECT rate FROM `rating`  where tailorid=" + loginUserID, (error, res5, field) => {
          let avgrate = 0;

          for (var i = 0; i < res5.length; i++) {
            avgrate = avgrate + res5[i].rate;
          }

          avgrate = avgrate / res5.length;





          if (res2.length > 0) {

            //  if(res2[0].type=="u"){

            //console.log('wellcome to users ');


            totalOrder = totalOrdersend;
            penddingorder = penddingordersend;
            totalTailor = totalTailorattach;
            avgratestar = avgrate;


            //  var token = jwt.sign({ username:res2[0].name }, 'shhhhh');
            //  res.header('Authorization',token);


            res.render('indexTailor', {
              "Username": res2[0].name,
              "type": res2[0].type,
              "imageaddress": res2[0].imageaddress,
              "totalOrdersend": totalOrdersend,
              "penddingordersend": penddingordersend,
              "totalTailorattach": totalTailorattach,
              "avgrate": avgrate


            });

          }
        })
      })


    })

      }





  });
})

let totalOrder = 0;
let penddingorder = 0;
let totalTailor = 0;
let avgratestar = 0;

app.post('/dashbord', (req, res) => {

  connection.query('SELECT * FROM login WHERE name = ? AND password = ?', [loginUserName, loginUserPassword], (error, res2, field) => {

    console.log(res2[0].type);

if (res2[0].type==="u"){

    loginUserID = res2[0].id;
    loginUserName = res2[0].name;
    loginUserImage = res2[0].imageaddress;

    var totalOrdersend = 0;
    var waitingforacceptsend = 0;
    var penddingordersend = 0;
    var totalTailorattach = 0;

    connection.query("SELECT * FROM `order`  where userid=" + loginUserID, (error, res3, field) => {

      for (var i = 0; i < res3.length; i++) {

        if (res3[i].orderStatus === "wfa") {
          waitingforacceptsend++;
        }
        //pendding
        if (res3[i].orderStatus === "pendding") {
          penddingordersend++;
        }

        totalOrdersend++;
      }


      connection.query("SELECT * FROM `history`  where userid=" + loginUserID, (error, res4, field) => {

        totalTailorattach = res4.length;

        //    res.redirect('http://localhost:3000/login');
        console.log('Total order send ' + totalOrdersend);
        console.log('waiting order send ' + waitingforacceptsend);
        console.log('pennding order send ' + penddingordersend);
        console.log('Tailor order send ' + totalTailorattach);

        if (res2.length > 0) {

          //  if(res2[0].type=="u"){

          //console.log('wellcome to users ');

          res.render('index', {
            "Username": loginUserName,
            "type": res2[0].type,
            "imageaddress": loginUserImage,
            "totalOrdersend": totalOrdersend,
            "waitingforacceptsend": waitingforacceptsend,
            "penddingordersend": penddingordersend,
            "totalTailorattach": totalTailorattach


          })}})})};


      //after user bord...


      if (res2[0].type==="t"){
           let totalOrdersend = 0;
    let penddingordersend = 0;
    let totalTailorattach = 0;


    connection.query("SELECT * FROM `order`  where tailorid=" + loginUserID, (error, res3, field) => {

      for (var i = 0; i < res3.length; i++) {


        //pendding
        if (res3[i].orderStatus === "confirm") {
          penddingordersend++;
        }

        totalOrdersend++;
      }


      connection.query("SELECT * FROM `history`  where tailorid=" + loginUserID, (error, res4, field) => {

        totalTailorattach = res4.length;

        //    res.redirect('http://localhost:3000/login');

        connection.query("SELECT rate FROM `rating`  where tailorid=" + loginUserID, (error, res5, field) => {
          let avgrate = 0;

          for (var i = 0; i < res5.length; i++) {
            avgrate = avgrate + res5[i].rate;
          }

          avgrate = avgrate / res5.length;






          if (res2.length > 0) {

            //  if(res2[0].type=="u"){

            //console.log('wellcome to users ');

            res.render('indexTailor', {
              "Username": res2[0].name,
              "type": res2[0].type,
              "imageaddress": res2[0].imageaddress,
              "totalOrdersend": totalOrdersend,
              "penddingordersend": penddingordersend,
              "totalTailorattach": totalTailorattach,
              "avgrate": avgrate


            });

          }
        })
      })


    })

        } 
 });

})




app.post('/bottom', (req, res) => {
  res.render('femalebottom.ejs', {
    "Username": loginUserName,
    "imageaddress": loginUserImage
  });

})


app.post('/top', (req, res) => {
  res.render('top.ejs', {
    "Username": loginUserName,
    "imageaddress": loginUserImage
  });

})



app.post('/topMeasurement', (req, res) => {
  res.render('topmeasurement.ejs', {
    "Username": loginUserName,
    "imageaddress": loginUserImage
  });

})

app.post('/dailywear', (req, res) => {
  res.render('dailytrend.ejs', {
    "Username": loginUserName,
    "imageaddress": loginUserImage
  });

})
app.post('/femaleartical', (req, res) => {
  res.render('femaleartical.ejs', {
    "Username": loginUserName,
    "imageaddress": loginUserImage
  });
})
app.post('/menartical', (req, res) => {
  res.render('menartical.ejs', {
    "Username": loginUserName,
    "imageaddress": loginUserImage
  });
})
app.post('/button', (req, res) => {
  res.render('button.ejs', {
    "Username": loginUserName,
    "imageaddress": loginUserImage
  });
})
app.post('/regtailor', (req, res) => {

  var arrayofindex = [];


  connection.query("SELECT * FROM history WHERE userid=" + loginUserID + " GROUP BY userid,tailorid HAVING COUNT(*) >= 1", (error, res2, field) => {



    //  console.log("SELECT * FROM history WHERE userid="+loginUserID+" GROUP BY userid,tailorid HAVING COUNT(*) >= 1");

    // "SELECT  historyId
    // FROM history
    // WHERE userid=16
    // GROUP BY userid,tailorid
    // HAVING COUNT(*) >= 1;

    //  connection.query("SELECT  * FROM history WHERE historyId="+7,(error,res3,field)=>{



    console.log(res2);


    res.render('history.ejs', {
      "result": res2,
      "Username": loginUserName,
      "imageaddress": loginUserImage
    });

    //})



    //  // u = {...u, city: 'Alabama'};
    //  var c=0;

    //  res2.forEach(function(u){
    //     //console.log('Now id ddddddddddddddddddddddd ' +u.tailorid);
    //     connection.query("SELECT rate FROM rating  where tailorid="+u.tailorid,(error,res3,field)=>{
    //      // u={...u, rate:res3[0] };
    //           u={...u, rate:res3[0] }
    //         console.log(u);
    //         c++;
    //     })
    //   })
    //  console.log(arrayofindex);








  });
})


// app.get('/:id' ,(req,res)=>{

//     console.log('By default calling this route'+req.params.id);
//     console.log(`Now User Name  : ${loginUserName}`)
//     console.log(`Now User Image  : ${loginUserImage}`)
//  connection.query("SELECT * FROM `order`  where orderid="+req.params.id,(error,res2,field)=>{

//    //console.log(res2);

//    res.render('./Order.ejs',{
//     "Username":loginUserName,
//     "imageaddress":loginUserImage,
//     "selecttailorid":SelectTailorID,
//     "imageaddress":loginUserImage ,
//     "result":res2,
//  });

//    });

// })
 // if (loginUserType==="u") {
app.get('/:id', (req, res) => {

    if (loginUserType==="u") {

       connection.query("UPDATE `notification` SET `notificationstatus`= '1'  WHERE `orderidfk` = " + req.params.id + " ", (error, res2, field) => {

    connection.query("SELECT * FROM `order`  where orderid=" + req.params.id, (error, res2, field) => {

      if (error) {
        console.log("SQL error is here : " + error.sqlMessage);
      }
      var buttonvisibilty = true;
      res.render('./Order.ejs', {
        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "result": res2,
        "buttonvisibilty": buttonvisibilty
      });
    });

  });
    }
     if (loginUserType==="t") {

     console.log(req.params.id);
  //  console.log(`Now User Name  : ${loginUserName}`)
  //  console.log(`Now User Image  : ${loginUserImage}`)
  connection.query("UPDATE `notification` SET `notificationstatus`= '1'  WHERE `orderidfk` = " + req.params.id + " ", (error, res2, field) => {

  });
  connection.query("SELECT * FROM `order`  where orderid=" + req.params.id, (error, res2, field) => {

    if (error) {
      console.log("SQL error is here : " + error.sqlMessage);
    }
    var buttonvisibilty = true;
    res.render('NotificationdetailTailor.ejs', {
      "Username": loginUserName,
      "imageaddress": loginUserImage,
      "result": res2,
      "buttonvisibilty": buttonvisibilty
    });
  });
    }
  // console.log(req.params.id);
  //  console.log(`Now User Name  : ${loginUserName}`)
  //  console.log(`Now User Image  : ${loginUserImage}`)
})
// }
//   console.log('asdasdasda sasda',loginUserType); 
// if (loginUserType==="t") {
  // console.log('tailorid is here t');

// }
app.post('/OrderForm', (req, res) => {

  console.log(` Here is the user for dropdown id :  ${req.body.dropdown} and here is taillor ${req.body.dropdowntailor} `);

  console.log(` Here is the user for dropdown id :  ${req.body.ldropdown} and here is taillor ${req.body.ldropdowntailor} `);

  if (req.body.dropdown == undefined && req.body.dropdowntailor == undefined) {
    console.log('undefine is running');
    SelectTailorName = req.body.ldropdowntailor
    SelectTailorID = req.body.ldropdown;

  }

  if (req.body.ldropdown == undefined && req.body.ldropdowntailor == undefined) {
    console.log('Define  is running');
    SelectTailorName = req.body.dropdowntailor
    SelectTailorID = req.body.dropdown;
  }





  res.render('OrderForm.ejs', {
    "Username": loginUserName,
    "imageaddress": loginUserImage
  });
})
app.post('/penddingOrder', (req, res) => {


  connection.query("SELECT * FROM `order` WHERE `tailorid` = " + loginUserID + " AND `orderStatus`= 'confirm'",
    (error, res2, field) => {

      res.render('OrderToTailor.ejs', {

        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "result": res2

      });
    })

})

app.post('/orderdetail', (req, res) => {


  let notificationStatus = 0;

  var notificationRecord = [loginUserID, loginUserName, nowTimer, req.body.currentuserid, req.body.currentusername, notificationStatus, req.body.orderidfordetail];

  if (req.body.clickbtn === "completed") {

    console.log('Compelte order is running')
    connection.query("INSERT INTO `notification` (`senderid`, `sendername`, `time`,`reciverid`,`recivername`,`notificationstatus`,`orderidfk`) VALUES (?)", [notificationRecord],
      (error, res2) => {
        if (error) {
          console.log("Notification error is : " + error.sqlMessage);
        }
        connection.query("UPDATE `order` SET `orderStatus`= 'completed'  WHERE `orderid` = " + req.body.orderidfordetail, (error, res2, field) => {
          if (error) {
            console.log("Update completed  error is : " + error.sqlMessage);
          }
        });
      })




  }



  connection.query("SELECT * FROM `order`  where orderid=" + req.body.orderidfordetail, (error, res2, field) => {

    if (error) {
      console.log("SQL error is here : " + error.sqlMessage);
    }

    var buttonvisibilty = false;
    res.render('notificationdetailTailor.ejs', {
      "Username": loginUserName,
      "imageaddress": loginUserImage,
      "result": res2,
      "buttonvisibilty": buttonvisibilty
    });

  });
})

app.post('/Order', (req, res) => {

  connection.query('SELECT status,tname,historyId FROM history  WHERE   userid=?', [loginUserID],
    (error, res2, field) => {
      console.log(res2);

      res.render('OrderTo.ejs', {

        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "availabletailor": res2,
        "alertdialog": alertdialoginformsubmission,
        "measurementdata":{
          "top" :30,
          "bottom":40
        }

      });

    })

})

let InsertedValue = function (valuesInsertedintoOrder) {

  console.log('Function is called');

  connection.query("INSERT INTO `order`(`tailorid`, `tailorname`, `userid`, `username`, `address`, `nap`, `orderdate`	, `enddate`, `service`, `message`, `orderStatus`) VALUES (?)", [valuesInsertedintoOrder],
    (error, res2) => {

      if (error) {
        console.log("SQL 1 error is here : " + error.sqlMessage);
      }

      var notificationStatus = 0;

      connection.query("SELECT MAX(orderid) AS ORDERID FROM `order`", (error, res) => {

        if (error) {
          console.log('sql error in max query' + error.sqlMessage);
        }


        var notificationRecord = [loginUserID, loginUserName, nowTimer, valuesInsertedintoOrder[0], valuesInsertedintoOrder[1], notificationStatus, res[0].ORDERID];

        connection.query("INSERT INTO `notification` (`senderid`, `sendername`, `time`,`reciverid`,`recivername`,`notificationstatus`,`orderidfk`) VALUES (?)", [notificationRecord],
          (error, res2) => { 
            
          })
      })
    })

  alertdialoginformsubmission = true;
  console.log('Function is end ');

};

let valuesInsertedintoOrder;
app.post('/submitform', (req, res) => {

  var orderStatus = "wfa";

  if (req.body.orderby === "directorder") {

    connection.query('SELECT tname,tailorid  FROM history  WHERE   historyid=?', [req.body.tailor],
      (error, res2, field) => {

        console.log('BY  Direct Order');

        console.log(`Tailor id is here ${res2[0].tailorid} and ` + res2[0].tname);

        valuesInsertedintoOrder = [
          res2[0].tailorid,
          res2[0].tname,
          loginUserID,
          loginUserName,
          req.body.address,
          req.body.nap,
          nowTimer,
          req.body.endDate,
          req.body.service,
          req.body.message,
          orderStatus
        ];

        InsertedValue(valuesInsertedintoOrder);
        //   console.log(valuesInsertedintoOrder);
      })
  }

  if (req.body.orderby === "byHistoryorder") {
    console.log('BY History Order');
    valuesInsertedintoOrder = [
      SelectTailorID,
      SelectTailorName,
      loginUserID,
      loginUserName,
      req.body.address,
      req.body.nap,
      nowTimer,
      req.body.endDate,
      req.body.service,
      req.body.message,
      orderStatus

    ];
    InsertedValue(valuesInsertedintoOrder);
  }



  connection.query('SELECT status,tname,historyId FROM history  WHERE   userid=?', [loginUserID],

    (error, res2, field) => {
      //      console.log(res2);

      //     console.log(res2);



      res.render('OrderTo.ejs', {

        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "availabletailor": res2

      });

    })

  //console.log(resp.sql);
});

app.post('/process', (req, res) => {

  //canceldelete

  if (req.body.btnclick === "canceldelete") {

    connection.query("DELETE  FROM `notification` WHERE  `orderidfk` = " + req.body.orderid, (error, res2, field) => {
    });

    connection.query("DELETE FROM `order` WHERE  `orderid` = " + req.body.orderid, (error, res2, field) => {
    });



    connection.query("SELECT * FROM `order` WHERE `userid` = " + loginUserID + " AND `orderStatus`= 'cancel'",
      (error, res2) => {

        if (error) {
          console.log("SQL 2 error is here : " + error.sqlMessage);
        }

        res.render('./Order.ejs', {
          "Username": loginUserName,
          "imageaddress": loginUserImage,
          "selecttailorid": SelectTailorID,
          "imageaddress": loginUserImage,
          "result": res2,

        });
      })


  }



  if (req.body.btnclick === "delete") {

    connection.query("DELETE  FROM `notification` WHERE  `orderidfk` = " + req.body.orderid, (error, res2, field) => {
    });

    connection.query("DELETE FROM `order` WHERE  `orderid` = " + req.body.orderid, (error, res2, field) => {
    });



    connection.query("SELECT * FROM `order` WHERE `userid` = " + loginUserID + " AND `orderStatus`= 'wtf'",
      (error, res2) => {

        if (error) {
          console.log("SQL 2 error is here : " + error.sqlMessage);
        }

        res.render('./Order.ejs', {
          "Username": loginUserName,
          "imageaddress": loginUserImage,
          "selecttailorid": SelectTailorID,
          "imageaddress": loginUserImage,
          "result": res2,

        });
      })


  }

  if (req.body.btnclick === "received") {

    connection.query("UPDATE `order` SET `orderStatus`= 'received'  WHERE `orderid` = " + req.body.orderid + " ", (error, res2, field) => {

      var valuesinserted = [
        req.body.orderid,
        loginUserID,
        req.body.tailorid,
        req.body.ratingval
      ]
      connection.query("INSERT INTO `rating`(`orderidfkr`,`userid`,`tailorid`,`rate`) VALUES (?)", [valuesinserted],
        (error, res2) => {

        })

      connection.query("SELECT * FROM `order`  WHERE `orderid` = " + req.body.orderid + "", (error, res2) => {

        var price = 0;
        var status = 1;


        var valuesinsertedhistory = [
          loginUserID,
          loginUserName,
          res2[0].tailorid,
          res2[0].tailorname,
          res2[0].message,
          price,
          status,
          nowTimer,
          req.body.ratingval
        ]


        connection.query("INSERT INTO `history`(`userid`, `username`, `tailorid`, `tname`, `detail`, `price`, `status`, `date`,`rate`) VALUES (?)", [valuesinsertedhistory],
          (error, res2) => {

          })
        connection.query("DELETE  FROM `notification` WHERE  `orderidfk` = " + req.body.orderid, (error, res2, field) => {
        });


      })

      if (error) {
        console.log("SQL Rating error is here : " + error.sqlMessage);
      }

      connection.query("SELECT * FROM `order` WHERE `userid` = " + loginUserID + " AND `orderStatus`= 'completed'",
        (error, res2) => {

          if (error) {
            console.log("SQL 2 error is here : " + error.sqlMessage);
          }

          res.render('./Order.ejs', {
            "Username": loginUserName,
            "imageaddress": loginUserImage,
            "selecttailorid": SelectTailorID,
            "imageaddress": loginUserImage,
            "result": res2,

          });
        })

    })

  }

})

app.get('*', (req, res) => res.send('Page Not found 404'));

app.post('/pennding', (req, res) => {

  console.log('now in penndinf')
  connection.query("SELECT * FROM `order` WHERE `userid` = " + loginUserID + " AND `orderStatus`= 'pendding'",
    (error, res2) => {

      if (error) {
        console.log("SQL 2 error is here : " + error.sqlMessage);
      }

      res.render('./Order.ejs', {
        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "selecttailorid": SelectTailorID,
        "imageaddress": loginUserImage,
        "result": res2,

      });
    })
});

//findtailor
// Find Tailor Here

function distance2(lat1, lon1, lat2, lon2) {
  var R = 6371; // Radius of the earth in km
  var dLat = (lat2 - lat1) * Math.PI / 180;  // deg2rad below
  var dLon = (lon2 - lon1) * Math.PI / 180;
  var a =
    0.5 - Math.cos(dLat) / 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    (1 - Math.cos(dLon)) / 2;

  return R * 2 * Math.asin(Math.sqrt(a));
}

app.post('/findtailor', (req, res) => {


  //     if(req.body.demos===undefined){

  //    console.log('Here lat and lng a: '+req.body.demos,req.body.lat, req.body.lng);

  //    var find=distance2(req.body.lat, req.body.lng ,34.155790, 73.219280)

  //   var round =Math.round(find);

  // console.log('after round'+round);

  //   connection.query("SELECT * FROM history  where userid="+null,(error,res2,field)=>{
  //     res.render('findtailor.ejs',{
  //        "result":res2,
  //        "Username":loginUserName,
  //        "imageaddress":loginUserImage
  //    });
  //    });

  //     }




  connection.query("SELECT * FROM login  where type='t'", (error, res2, field) => {


    let count = 0;
    let dataarray = [];
    let index = 0;

    res2.forEach(function (user) {
      console.log(req.body.lat, req.body.lng, res2[count].lat, res2[count].lng);

      var find = distance2(req.body.lat, req.body.lng, res2[count].lat, res2[count].lng);

      var round = Math.round(find);


      if (round <= req.body.distance) {
        // console.log('hERE round inside   : '+round);
        res2[count].roundDistance = round;
        dataarray[index] = res2[count];
        console.log(dataarray[index]);
        index++;
      }
      // console.log('hERE FOECAF : ' + round);
      count++;
    });

    if (error) {
      console.log('sql no error ', error);
    }


    let rangevalue = req.body.rangevalue;
    console.log('Rnage value is here ' + rangevalue);

    connection.query("SELECT lat ,lng FROM login WHERE id =" + loginUserID, (error, latlng, field) => {
      
      res.render('findtailor.ejs', {
        "result": dataarray,
        "sliderrange": rangevalue,
        "latlng": latlng,
        "Username": loginUserName,
        "imageaddress": loginUserImage
      });


    });
  });

});


app.post('/serviceAvailable', (req, res) => {

  console.log(` Here is the user for dropdown id :  ${req.body.dropdown} and here is taillor ${req.body.dropdowntailor} `);

  console.log(` Here is the user for dropdown id :  ${req.body.ldropdown} and here is taillor ${req.body.ldropdowntailor} `);

  if (req.body.dropdown == undefined && req.body.dropdowntailor == undefined) {
    console.log('undefine is running');
    SelectTailorName = req.body.ldropdowntailor
    SelectTailorID = req.body.ldropdown;

  }

  if (req.body.ldropdown == undefined && req.body.ldropdowntailor == undefined) {
    console.log('Define  is running');
    SelectTailorName = req.body.dropdowntailor
    SelectTailorID = req.body.dropdown;
  }

  connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory != ? ', [req.body.ldropdown, 'extra'], (error, res3, field) => {
    // console.log(util.inspect(res3, false, null, true /* enable colors */));
    connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? ', [req.body.ldropdown, 'extra'], (error, extra, field) => {
      
      res.render('./serviceProvider.ejs', {
        msg: "",
        "result": res3,
        "Username": loginUserName,
        "extraResult":extra,
        "imageaddress": loginUserImage,
      });
  })
})
});
app.post('/cancel', (req, res) => {

  console.log('now in penndinf')
  connection.query("SELECT * FROM `order` WHERE `userid` = " + loginUserID + " AND `orderStatus`= 'cancle'",
    (error, res2) => {
      if (error) {
        console.log("SQL 2 error is here : " + error.sqlMessage);
      }
      res.render('./Order.ejs', {
        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "selecttailorid": SelectTailorID,
        "imageaddress": loginUserImage,
        "result": res2,

      });
    })
});
app.post('/wfa', (req, res) => {

  console.log('now in penndinf')
  connection.query("SELECT * FROM `order` WHERE `userid` = " + loginUserID + " AND `orderStatus`= 'wfa'",
    (error, res2) => {

      if (error) {
        console.log("SQL 2 error is here : " + error.sqlMessage);
      }

      res.render('./Order.ejs', {
        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "selecttailorid": SelectTailorID,
        "imageaddress": loginUserImage,
        "result": res2,
        "dateFormat": dateFormat,

      });
    })
});
//orderMeasure
app.post('/orderMeasure', (req, res) => {

  var selectOrderProfileid =req.body.selectedOrderId;
  
      res.render('./topmeasurement.ejs', {
        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "selecttailorid": SelectTailorID,
        "imageaddress": loginUserImage,
        "selectOrderProfileid":selectOrderProfileid,
      });
  });
app.post('/completeOrderBymeasure', (req, res) => {

  var selectOrderProfileid =req.body.selectedOrderId;
  
        console.log('====================================');
        console.log(req.body.options);
        console.log('====================================');
  
      res.render('./topmeasurement.ejs', {
        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "selecttailorid": SelectTailorID,
        "imageaddress": loginUserImage,
        "selectOrderProfileid":selectOrderProfileid
      });
  });
app.post('/History', (req, res) => {

  console.log('now in penndinf')
  connection.query("SELECT * FROM `order` where userid= " + loginUserID + "",
    (error, res2) => {

      if (error) {
        console.log("SQL 2 error is here : " + error.sqlMessage);
      }

      res.render('./Order.ejs', {
        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "selecttailorid": SelectTailorID,
        "imageaddress": loginUserImage,
        "result": res2,

      });
    })
});
//History
const storage = multer.diskStorage({
  destination: './public/images/faces',
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }
});
function checkFileType(file, cb) {
  // Allowed ext
  const filetypes = /jpeg|jpg|png|gif/;
  // Check ext
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  // Check mime
  const mimetype = filetypes.test(file.mimetype);

  if (mimetype && extname) {
    return cb(null, true);
  } else {
    cb('Error: Images Only!');
  }
}
const upload = multer({
  storage: storage,
  limits: { fileSize: 1000000 },
  fileFilter: function (req, file, cb) {
    checkFileType(file, cb);
  }
}).single('file');

app.post('/UploadFile', (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      res.render('signUp', {
        msg: err
      });
    } else {
      if (req.file == undefined) {
        res.render('signUp', {
          msg: 'Error: No File Selected!'
        });
      } else {
        var values = [req.body.username, req.body.password, req.body.email, req.body.address, req.body.type, req.file.originalname,
        req.body.lat, req.body.lng
        ];

        console.log(values);
        connection.query("INSERT INTO `login` ( `profileid`, `name`, `price`, `image`, `catagory`, `type`) VALUES (?)", [values],
          (error, res2, field) => {
            if (!error) {
              res.render('login.ejs', {
                word: res2
              })
            }
            if (error) {
              res.redirect('/signUp');
            }
            res.render('login', {
              msg: 'File Uploaded!',
              file: `uploads/${req.file.filename}`
            });
          });
      }
    }
  })
});

app.post('/delete', (req, res) => {

  connection.query("UPDATE `order` SET `orderStatus`= 'deleted'  WHERE `orderid` = " + req.body.orderid + " ", (error, res2, field) => {


    connection.query("SELECT * FROM `order` WHERE `tailorid` = " + loginUserID + " AND `orderStatus`= 'pendding'",
      (error, res2) => {

        if (error) {
          console.log("SQL 2 error is here : " + error.sqlMessage);
        }

        res.render('./OrderTailor.ejs', {
          "Username": loginUserName,
          "imageaddress": loginUserImage,
          "selecttailorid": SelectTailorID,
          "imageaddress": loginUserImage,
          "result": res2,

        });
      })



  });
})

//app.listen(4000,()=>console.log('Listen at port 4000'));
app.post('/complete', (req, res) => {

  console.log('now in penndinf')
  connection.query("SELECT * FROM `order` WHERE `tailorid` = " + loginUserID + " AND `orderStatus`= 'completed'",
    (error, res2) => {


      if (error) {
        console.log("SQL 2 error is here : " + error.sqlMessage);
      }

      res.render('./OrderTailor.ejs', {
        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "selecttailorid": SelectTailorID,
        "imageaddress": loginUserImage,
        "result": res2,

      });
    })
});

app.post('/cancelOrders', (req, res) => {
  console.log('Now in cancel order');
  connection.query("SELECT * FROM `order` WHERE `tailorid` = " + loginUserID + " AND `orderStatus`= 'cancel'",
    (error, res2) => {
      if (error) {
        console.log("SQL 2 error is here : " + error.sqlMessage);
      }

      res.render('./OrderTailor.ejs', {
        "Username": loginUserName,
        "imageaddress": loginUserImage,
        "selecttailorid": SelectTailorID,
        "imageaddress": loginUserImage,
        "result": res2,

      });
    })
});
app.post('/confirm', (req, res) => {

  // console.log('button click id '+req.body.buttonsubmit);
  // console.log(`nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn ${req.body.currentorderid}`);
  if (req.body.buttonsubmit === "Confirm") {
    let notificationStatus = 0;
    var notificationRecord = [loginUserID, loginUserName, nowTimer, req.body.currentuserid, req.body.currentusername, notificationStatus, req.body.currentorderid];

    connection.query("UPDATE `order` SET `orderStatus`= 'confirm'  WHERE `orderid` = " + req.body.currentorderid, (error, res2, field) => {
    });
    connection.query("INSERT INTO `notification` (`senderid`, `sendername`, `time`,`reciverid`,`recivername`,`notificationstatus`,`orderidfk`) VALUES (?)", [notificationRecord],
      (error, res2) => {

        if (error) {

          console.log(error.sqlMessage);
        }

      });

  }

  if (req.body.buttonsubmit === "Cancel") {
    let notificationStatus = 0;
    var notificationRecord = [loginUserID, loginUserName, nowTimer, req.body.currentuserid, req.body.currentusername, notificationStatus, req.body.currentorderid];

    connection.query("UPDATE `order` SET `orderStatus`= 'cancel'  WHERE `orderid` = " + req.body.currentorderid, (error, res2, field) => {
    });
    connection.query("INSERT INTO `notification` (`senderid`, `sendername`, `time`,`reciverid`,`recivername`,`notificationstatus`,`orderidfk`) VALUES (?)", [notificationRecord],
      (error, res2) => {

        if (error) {

          console.log(error.sqlMessage);
        }

      });
  }
  //
  // connection.query("DELETE FROM `notification` WHERE  `orderidfk` = "+req.body.currentorderid,(error,res2,field)=>{
  // });

  res.render('./indexTailor.ejs', {
    "Username": loginUserName,
    "imageaddress": loginUserImage,
    "selecttailorid": SelectTailorID,
    "imageaddress": loginUserImage,
    "totalOrdersend": totalOrder,
    "penddingordersend": penddingorder,
    "totalTailorattach": totalTailor,
    "avgrate": avgratestar
  })

})



app.post('/service', (req, res) => {

  console.log('here service is running with data');
  connection.query('SELECT * FROM tailorprofile  where loginid = ? AND catagory != ?', [loginUserID, 'extra'], (error, res3, field) => {
    // console.log(util.inspect(res3, false, null, true /* enable colors */))
    connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ?', [loginUserID, 'extra'], (error, extra, field) => {


      res.render('serviceProvideTailor.ejs', {
        msg: "",
        "result": res3,
        "Username": loginUserName,
        "extraResult": extra,
        "imageaddress": loginUserImage,
      });



    })
  })
});
app.post('/services', (req, res) => {
  connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ?', [loginUserID, '0', 'extra'], (error, res3, field) => {

    connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '0'], (error, extra, field) => {

      res.render('serviceProvideTailor.ejs', {
        msg: "",
        "result": res3,
        "Username": loginUserName,
        "extraResult": extra,
        "imageaddress": loginUserImage,
      });

    })

  })
});
app.post('/Servicem', (req, res) => {
  connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ? ', [loginUserID, '1', 'extra'], (error, res3, field) => {
    connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '1'], (error, extra, field) => {


      res.render('serviceProvideTailor.ejs', {
        msg: "",
        "result": res3,
        "Username": loginUserName,
        "extraResult": extra,
        "imageaddress": loginUserImage,
      });



    })

  })

});
app.post('/serviced', (req, res) => {

  connection.query("Delete  FROM `tailorprofile`  where profileid=" + req.body.deleteId, (error, res2, field) => {
    if (req.body.deleteuser === '1') {
      connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory != ? AND type = ?', [loginUserID, 'extra', '1'], (error, res3, field) => {

        connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '1'], (error, extra, field) => {


          res.render('serviceProvideTailor.ejs', {
            msg: "",
            "result": res3,
            "Username": loginUserName,
            "extraResult": extra,
            "imageaddress": loginUserImage,
          });



        })


      })
    }
    if (req.body.deleteuser === '0') {
      connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory != ? AND type = ?', [loginUserID, 'extra', '0'], (error, res3, field) => {

        connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '0'], (error, extra, field) => {


          res.render('serviceProvideTailor.ejs', {
            msg: "",
            "result": res3,
            "Username": loginUserName,
            "extraResult": extra,
            "imageaddress": loginUserImage,
          });



        })


      })
    }
  });
});

app.post('/UploadFileTailor', (req, res) => {

  upload(req, res, (err) => {
    if (err) {
      res.render('serviceProvideTailor.ejs', {
        "result": "",
        "Username": loginUserName,
        "imageaddress": loginUserImage,
        msg: err
      });
    } else {
      if (req.file == undefined) {
        res.render('serviceProvideTailor.ejs', {
          "result": "",
          "Username": loginUserName,
          "imageaddress": loginUserImage,
          msg: 'Error: No File Selected!'
        });
      } else {

        var values = [loginUserID, req.body.name, req.body.price, req.file.originalname, req.body.Category, req.body.type];
        //
         console.log(values);
        connection.query("INSERT INTO `tailorprofile` (`loginid`,`name`, `price`, `image`, `catagory`, `type` ) VALUES (?)", [values],
          (error, res2, field) => {
            

            if (error) {
              res.render('serviceProvideTailor.ejs', {
                "result": "",
                "Username": loginUserName,
                "imageaddress": loginUserImage,
                msg:error

              });
            }

            if (req.body.deleteuser === '1') {
              connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ?', [loginUserID, '1', 'extra'], (error, res3, field) => {

                connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '1'], (error, extra, field) => {


                  res.render('serviceProvideTailor.ejs', {
                    msg: "",
                    "result": res3,
                    "Username": loginUserName,
                    "extraResult": extra,
                    "imageaddress": loginUserImage,
                  });



                })


              })
            }
            if (req.body.deleteuser === '0') {
              connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ?', [loginUserID, '0', 'extra'], (error, res3, field) => {

                connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '0'], (error, extra, field) => {


                  res.render('serviceProvideTailor.ejs', {
                    msg: "",
                    "result": res3,
                    "Username": loginUserName,
                    "extraResult": extra,
                    "imageaddress": loginUserImage,
                  });



                })


              })
            }


            //  if(!error){
            //     res.render('serviceProvide.ejs',{
            //       "result":"",
            //       "Username":loginUserName,
            //       "imageaddress":loginUserImage ,
            //       msg: 'Uploaded!'

            //     })
            //  }


          });
      }
    }
  })
});

app.post('/addExtraFile', (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      res.render('serviceProvideTailor.ejs', {
        "result": "",
        "Username": loginUserName,
        "imageaddress": loginUserImage,
        msg: err
      });
    } else {
      if (req.file == undefined) {
        res.render('serviceProvideTailor.ejs', {
          "result": "",
          "Username": loginUserName,
          "imageaddress": loginUserImage,
          msg: 'Error: No File Selected!'
        });
      } else {
        var values = [loginUserID, req.body.name, req.body.price, req.file.originalname, 'extra', req.body.type];

        console.log(values);
        connection.query("INSERT INTO `tailorprofile` (`loginid`,`name`, `price`, `image`, `catagory`, `type` ) VALUES (?)", [values],
          (error, res2, field) => {
            //  if(!error){
            //       res.render('serviceProvide.ejs',{
            //         "result":"",
            //         "Username":loginUserName,
            //         "imageaddress":loginUserImage ,
            //         msg: 'Uploaded!'

            //       })
            //    }

            if (error) {
              res.render('serviceProvideTailor.ejs', {
                "result": "",
                "Username": loginUserName,
                "imageaddress": loginUserImage,
                msg: 'error in sub'

              });
            }

            if (req.body.type === '1') {
              connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ?', [loginUserID, '1', 'extra'], (error, res3, field) => {

                connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '1'], (error, extra, field) => {


                  res.render('serviceProvideTailor.ejs', {
                    msg: "",
                    "result": res3,
                    "Username": loginUserName,
                    "extraResult": extra,
                    "imageaddress": loginUserImage,
                  });
                })
              })
            }
            if (req.body.type === '0') {
              connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ?', [loginUserID, '0', 'extra'], (error, res3, field) => {

                connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '0'], (error, extra, field) => {


                  res.render('serviceProvideTailor.ejs', {
                    msg: "",
                    "result": res3,
                    "Username": loginUserName,
                    "extraResult": extra,
                    "imageaddress": loginUserImage,
                  });



                })


              })
            }
          });
      }
    }
  })
});

app.post('/completehistory', (req, res) => {
  connection.query("SELECT * FROM `order`  where tailorid=" + loginUserID, (error, res2, field) => {
    res.render('./OrderTailor.ejs', {
      "result": res2,
      "Username": loginUserName,
      "imageaddress": loginUserImage
    })
  });
});